>> ApplicationLib Folder
----------------------------------------------------------------------------------
-- "TestCaseExecution.vbs" is reference implementation from GQS framework.
-- Advanced UFT users may modify it to extend with custom logics. For any other
-- project level application libraries (i.e. VBS files), please store them in
-- this folder and framework will load them automatically before executing any
-- of your automation scripts.
----------------------------------------------------------------------------------
