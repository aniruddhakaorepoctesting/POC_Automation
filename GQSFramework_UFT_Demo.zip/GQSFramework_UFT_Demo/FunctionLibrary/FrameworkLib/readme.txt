>> FrameworkLib Folder
----------------------------------------------------------------------------------
-- This folder stores GQS framework libraries and please do *NOT* change
-- anything here for your project. All vbs and dll libaries will be loaded by
-- framework automatically.
----------------------------------------------------------------------------------
