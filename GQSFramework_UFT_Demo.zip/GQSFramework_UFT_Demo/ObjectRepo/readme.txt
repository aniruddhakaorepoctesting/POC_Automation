ObjectReop
--------------------------------
Put all the object repository .tsr files under this folder.